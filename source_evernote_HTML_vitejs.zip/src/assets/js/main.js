import './../js/alpinejs@3.9.1.min.js'
import './../css/style.css'